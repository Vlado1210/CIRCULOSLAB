﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BouncingBall
{
    public partial class Form1 : Form
    {
       
        private int ballWidth = 20;
        private int ballHeight = 20;
        private int ballPosX = 0;
        private int ballPosY = 0;

        private int ballWidth1 = 40;
        private int ballHeight1 = 40;
        private int ballPosX1 = 200;
        private int ballPosY1 = 70;
        private int ballWidth2 = 30;
        private int ballHeight2 = 30;
        private int ballPosX2 = 130;
        private int ballPosY2 = 90;

        private int moveStepX = 4;
        private int moveStepY = 4;
        private int moveStepX1 = 4;
        private int moveStepY1= 4;
        private int moveStepX2 = 4;
        private int moveStepY2 = 4;

        public Form1()
        {
            InitializeComponent();

            this.SetStyle(
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint,
                true
                );

            this.UpdateStyles();
        }

        private void PaintCircle(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = 
                System.Drawing.Drawing2D.SmoothingMode.AntiAlias;


          
            e.Graphics.FillEllipse(Brushes.Blue,
                ballPosX, ballPosY,
                ballWidth, ballHeight);

            e.Graphics.DrawEllipse(Pens.Black,
                ballPosX1, ballPosY1,
                ballWidth1, ballHeight1);
            e.Graphics.FillEllipse(Brushes.Red,
              ballPosX1, ballPosY1,
              ballWidth1, ballHeight1);

            e.Graphics.DrawEllipse(Pens.Black,
                ballPosX, ballPosY,
                ballWidth, ballHeight);
            e.Graphics.DrawEllipse(Pens.Black,
             ballPosX2, ballPosY2,
             ballWidth2, ballHeight2);
            e.Graphics.FillEllipse(Brushes.Yellow,
              ballPosX2, ballPosY2,
              ballWidth2, ballHeight2);
        }

        private void MoveBall(object sender, EventArgs e)
        {
            
            ballPosX += moveStepX;
            ballPosX1 += moveStepX1;
            ballPosX2 += moveStepX2;
            if (
                ballPosX < 0  ||
                ballPosX + ballWidth > this.ClientSize.Width
               )
            {
                moveStepX = -moveStepX;
            }

            ballPosY += moveStepY;
            if (
                ballPosY < 0 ||
                ballPosY + ballHeight > this.ClientSize.Height
                )
            {
                moveStepY = -moveStepY;
            }
            if (
                ballPosX1 < 0 ||
                ballPosX1 + ballWidth1 > this.ClientSize.Width
               )




            {
                moveStepX1 = -moveStepX1;
            }

            ballPosY1 += moveStepY1;
            if (
                ballPosY1 < 0 ||
                ballPosY1 + ballHeight1 > this.ClientSize.Height
                )
            {
                moveStepY1 = -moveStepY1;
            }
            if (
                ballPosX2 < 0 ||
                ballPosX2 + ballWidth2 > this.ClientSize.Width
               )




            {
                moveStepX2 = -moveStepX2;
            }

            ballPosY2 += moveStepY2;
            if (
                ballPosY2 < 0 ||
                ballPosY2 + ballHeight2 > this.ClientSize.Height
                )
            {
                moveStepY2 = -moveStepY2;
            }
            if (ballPosX + ballWidth > ballPosX1 + ballWidth1)
            {
                moveStepX1 = -moveStepX1;
                moveStepX = -moveStepX;
            }
            if (ballPosY + ballHeight > ballPosY1 + ballHeight1)
            {
                moveStepY1 = -moveStepY1;
                moveStepY = -moveStepY;
            }
            if (ballPosX + ballWidth > ballPosX2 + ballWidth2)
            {
                moveStepX2 = -moveStepX2;
                moveStepX = -moveStepX;
            }
            if (ballPosY + ballHeight > ballPosY2 + ballHeight2)
            {
                moveStepY2 = -moveStepY2;
                moveStepY = -moveStepY;
            }
            if (ballPosX2 + ballWidth2 > ballPosX1 + ballWidth1)
            {
                moveStepX1 = -moveStepX1;
                moveStepX2 = -moveStepX2;
            }
            if (ballPosY + ballHeight > ballPosY2 + ballHeight2)
            {
                moveStepY2 = -moveStepY2;
                moveStepY = -moveStepY;
            }


            this.Refresh();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
